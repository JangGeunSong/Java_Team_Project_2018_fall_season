import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class UserDefinedHistoryFrame extends JFrame{

    private UserDefinedHistoryPanel primary;
    private EntryPanel Tree[];
    private JScrollPane p;
    public UserDefinedHistoryFrame(int entryNum, ArrayList<EntryComponent> parameter) {
        // TODO Auto-generated constructor stub
        int k = parameter.size();
        Tree = new EntryPanel[k];

        this.setPreferredSize(new Dimension(144*9, 90*9));

        for(int i = 0; i < k; i++){
            Tree[i] = new EntryPanel(0,0,parameter.get(i));
        }

        primary = new UserDefinedHistoryPanel(entryNum, Tree);
        add(primary);

        p = new JScrollPane(primary);
        add(p);

        pack();
        setVisible(true);
    }

    public void reNewTree(ArrayList<EntryComponent> parameter){
        int k = parameter.size();
        for(int i = 0; i < k; i++){
            Tree[i].setEntryComponent(parameter.get(i));
        }
        primary.setEntryTree(Tree);
    }
}
