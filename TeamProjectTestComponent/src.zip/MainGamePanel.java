import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class MainGamePanel extends JPanel{
    private EntryPanel leftPanel, rightPanel;
    //화면에 뿌릴 실제 패널
    private JButton btnH;
    //History Panel을 띄우기 위해 만든 버튼
    private ButtonListener btnL;
    //버튼이 작동하게 만들기 위한 리스너
    private PanelClickDetect dteP;
    //패널이 클릭되었을때 그게 어떤건지 인지하게 만들기 위한 리스너
    private Timer aniTimer, resetTimer;
    //패널이 움직이는것을 구현하기 위한 aniTimer와 다음 라운드로 넘어가기 위해 선언한 resetTimer
    private String Type;
    //게임의 주제 즉 어떤 이상형 월드컵인지 선택된 내용을 받아주는 type
    private int nRound, nElem, nWinner, nNextMatch, rBound, signal;
    //각 토너먼트 별로 지정해야할 배열의 개수와 다음 매치의 순서가 달라지므로 이를 정하기 위해 선언한 변수
    private ArrayList<EntryComponent> eTree;
    private ArrayList<EntryPanel> Tree;
    // 각 엔트리의 정보를 담을 자료구조 EntryComponent와 EntryPanel 을 ArrayList로 제작
    private UserDefinedHistoryFrame UDHF;
    private getImgRes imString;

    public MainGamePanel(String Type, int Round) {
        int i = 0;
        this.setBackground(Color.WHITE);
        this.setPreferredSize(new Dimension(1440,900));
        this.setLayout(null);

        dteP = new PanelClickDetect();

        this.Type = Type;
        this.nRound = Round;
        this.nElem = (this.nRound * 2) - 1;
        this.nNextMatch = nElem/2;
        this.rBound = nElem - 1;
        this.signal = 0;
        

        eTree = new ArrayList<EntryComponent>();
        Tree = new ArrayList<EntryPanel>();

        for (i = 0; i < nElem; i++){
            eTree.add(new EntryComponent("./Images/새.jpg","./Images/새2.jpg", ""+i, 0));
        }

        for(i = 0; i < nElem; i++) {
            Tree.add(new EntryPanel(10,60,eTree.get(i)));
        }

        for(i = 0; i < nElem; i++){
            Tree.get(i).addMouseListener(dteP);
        }

        UDHF = new UserDefinedHistoryFrame(nElem + 1, eTree);
        UDHF.setTitle("현재상황");
        UDHF.setVisible(false);

        System.out.println(this.Type);
        System.out.println(this.nRound);

        leftPanel = Tree.get(nNextMatch);
        leftPanel.setPtX(10);
        leftPanel.setPtY(60);
        leftPanel.setLocation(leftPanel.getPtX(),leftPanel.getPtY());
        leftPanel.repaint();
        this.add(leftPanel);
        //leftPanel.addMouseListener(dteP);

        rightPanel = Tree.get(nNextMatch + 1);
        rightPanel.setPtX(720);
        rightPanel.setPtY(60);
        rightPanel.setLocation(rightPanel.getPtX(),rightPanel.getPtY());
        rightPanel.repaint();
        this.add(rightPanel);
        //rightPanel.addMouseListener(dteP);

        btnH = new JButton("HISTORY");
        btnH.setBounds(1200,10,200,40);
        btnH.setFont(new Font("Consolas", Font.BOLD, 30));
        btnH.setForeground(Color.WHITE);
        btnH.setBackground(Color.BLACK);
        this.add(btnH);

        btnL = new ButtonListener();
        btnH.addActionListener(btnL);

    }

    public void reset(int nLeft, int nRight, int signal) {
        if(signal == 0) {
            leftPanel.setVisible(false);
            rightPanel.setVisible(false);
            leftPanel = null;
            leftPanel = Tree.get(nLeft);
            leftPanel.setPtX(10);
            leftPanel.setPtY(60);
            leftPanel.setLocation(leftPanel.getPtX(), leftPanel.getPtY());
            //leftPanel.addMouseListener(dteP);
            this.add(leftPanel);
            leftPanel.setVisible(true);
            rightPanel = null;
            rightPanel = Tree.get(nRight);
            rightPanel.setPtX(720);
            rightPanel.setPtY(60);
            rightPanel.setLocation(rightPanel.getPtX(), rightPanel.getPtY());
            //rightPanel.addMouseListener(dteP);
            this.add(rightPanel);
            rightPanel.setVisible(true);
            this.repaint();
        }
        else{

        }
    }

    private class ButtonListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e){
            Object obj = e.getSource();
            if(obj == btnH){
                UDHF.setVisible(true);
            }
        }
    }

    private class PanelClickDetect implements MouseListener{
        @Override
        public void mouseClicked(MouseEvent e){
            Object obj = e.getSource();
            if(obj == rightPanel){
                nWinner = nNextMatch;
                nNextMatch = nNextMatch + 2;
                rightPanel.setVelocity(3);
                leftPanel.setVisible(false);
                Tree.set((nNextMatch-2)/2, rightPanel);
                //Tree.get(nNextMatch/2).add(Tree.get(nWinner));
                aniTimer = new Timer(1, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e){
                        aniTimer.start();
                        if(rightPanel.getPtX() > 400){
                            rightPanel.setPtX(rightPanel.getPtX() - rightPanel.getVelocity());
                            rightPanel.setLocation(rightPanel.getPtX(), rightPanel.getPtY());
                            rightPanel.repaint();
                            aniTimer.setRepeats(true);
                        }
                        else if(rightPanel.getPtX() <= 400){
                            resetTimer = new Timer(2500, new ActionListener(){
                                @Override
                                public void actionPerformed(ActionEvent e){
                                    resetTimer.start();
                                    if(nNextMatch >= rBound && (nNextMatch-2)/2 != 0) {
                                        rBound = rBound / 2;
                                        nNextMatch = (rBound / 2);
                                    }
                                    else if((nNextMatch-2)/2 == 0){
                                        System.out.println("Panel Change!");
                                        signal = 1;
                                    }
                                    reset(nNextMatch, nNextMatch + 1, signal);
                                    resetTimer.stop();
                                }
                            });
                            resetTimer.start();
                            aniTimer.stop();
                        }
                    }
                });
                aniTimer.start();
            }
            else if(obj == leftPanel){
                nWinner = nNextMatch + 1;
                nNextMatch = nNextMatch + 2;
                leftPanel.setVelocity(3);
                rightPanel.setVisible(false);
                Tree.set((nNextMatch-2)/2, leftPanel);
                //Tree.get(nNextMatch/2).add(Tree.get(nWinner));
                aniTimer = new Timer(1, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e){
                        aniTimer.start();
                        if(leftPanel.getPtX() < 400){
                            leftPanel.setPtX(leftPanel.getPtX() + leftPanel.getVelocity());
                            leftPanel.setLocation(leftPanel.getPtX(), leftPanel.getPtY());
                            leftPanel.repaint();
                            aniTimer.setRepeats(true);
                        }
                        else if(leftPanel.getPtX() >= 400){
                            resetTimer = new Timer(2500, new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent a){
                                    resetTimer.start();
                                    if(nNextMatch >= rBound && (nNextMatch-2)/2 != 0) {
                                        rBound = rBound / 2;
                                        nNextMatch = (rBound / 2);
                                    }
                                    else if((nNextMatch-2)/2 == 0){
                                        System.out.println("Panel Change!");
                                        signal = 1;
                                    }

                                    reset(nNextMatch, nNextMatch + 1, signal);
                                    resetTimer.stop();
                                }
                            });
                            resetTimer.start();
                            aniTimer.stop();
                        }
                    }
                });
                aniTimer.start();
            }
        }
        @Override
        public void mousePressed(MouseEvent e){

        }
        @Override
        public void mouseReleased(MouseEvent e){

        }
        @Override
        public void mouseEntered(MouseEvent e){

        }
        @Override
        public void mouseExited(MouseEvent e){

        }
    }
}
