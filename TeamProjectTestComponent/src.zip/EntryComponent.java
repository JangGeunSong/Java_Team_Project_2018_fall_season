import javax.swing.ImageIcon;

public class EntryComponent implements Comparable<EntryComponent>{
    public ImageIcon image;
    public String name;
    public int victoryNum;

    public EntryComponent(String imageDir, String ImageDir2, String name, int victoryNum){
        image = new ImageIcon(imageDir);
        this.name = name;
        this.victoryNum = victoryNum;
    }

	@Override
	public int compareTo(EntryComponent arg) {
		return victoryNum - arg.victoryNum;

	}
}
